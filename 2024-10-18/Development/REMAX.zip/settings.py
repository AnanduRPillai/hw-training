# settings.py

import os

# MongoDB configuration
MONGODB_URI = os.getenv("MONGODB_URI", "mongodb://localhost:27017/")
DATABASE_NAME = os.getenv("DATABASE_NAME", "REMAX_2024_10_18")
COLLECTION_PROFILE_URLS = "REMAX_profile_url_crawler"
COLLECTION_AGENT_DETAILS = "REMAX_parser"

# Logging configuration
LOGGING_LEVEL = 'INFO'
LOGGING_FILENAME = 'agent_scraper.log'
