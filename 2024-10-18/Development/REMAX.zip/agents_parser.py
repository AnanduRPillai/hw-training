import requests
from parsel import Selector
import logging
from settings import LOGGING_LEVEL, LOGGING_FILENAME
from pipelines import MongoDBPipeline
from bs4 import BeautifulSoup

# Set up logging
logging.basicConfig(level=LOGGING_LEVEL, filename=LOGGING_FILENAME,
                    format='%(asctime)s - %(levelname)s - %(message)s')


class REMAXAgentScraper:
    def __init__(self):
        self.pipeline = MongoDBPipeline()
        self.base_url_template = "https://global.remax.com/handlers/officeagentsearch.ashx?mode=list&type=2&regionId=1000&regionRowId=&provinceId=&cityId=&localzoneId=&name=&location=&spokenLanguageCode=&page={}&countryCode=US&countryEnuName=USA&countryName=USA&selmode=residential&officeId=&TargetLng=&TargetLat="
        self.page = 1

    def get_agent_profile_urls(self):
        base_url = self.base_url_template.format(self.page)
        try:
            response = requests.get(base_url)
            response.raise_for_status()
            soup = BeautifulSoup(response.text, 'html.parser')
            agent_items = soup.find_all('div', class_='officeagent-list-item')

            agents = []
            for agent_item in agent_items:
                profile_url = agent_item.find('a', class_='officeagent-pic')['href']
                style = agent_item.find('a', class_='officeagent-pic')['style']
                image_url = style.split("url('")[1].split("')")[0]
                agent_name = agent_item.find('a', class_='agent-name').text.strip()

                # Split the name into first, middle, and last names
                name_parts = agent_name.split()
                first_name = name_parts[0] if len(name_parts) > 0 else ""
                middle_name = " ".join(name_parts[1:-1]) if len(name_parts) > 2 else ""
                last_name = name_parts[-1] if len(name_parts) > 1 else ""

                agents.append({
                    'profile_url': profile_url,
                    'image_url': image_url,
                    'first_name': first_name,
                    'middle_name': middle_name,
                    'last_name': last_name
                })

                # Insert profile URL into MongoDB
                self.pipeline.process_agent_details({'profile_url': profile_url})

            logging.info(f"Fetched and saved {len(agents)} profile URLs.")
            return agents

        except requests.RequestException as e:
            logging.error(f"Request error for URL {base_url}: {e}")
            return []

    def fetch_agent_details(self, url):
        try:
            # Fetch the page content
            response = requests.get(url)
            response.raise_for_status()  # Check for HTTP errors
            response = Selector(text=response.text)

            # XPATH definitions
            PURPOSE_XPATH = '//li/span[@aria-label="Purpose"]/text()'
            office_phone_xpath = "//span[@id='OfficePhoneSpan']/text()"
            fax_number_xpath = "//span[@id='FaxSpan']/text()"
            agent_phone_xpath = "//span[@id='PhoneSpan']/text()"
            address_xpath = "//div[@itemtype='http://schema.org/PostalAddress']/span[@class='office-address']/text()"
            office_name_xpath = '//div[@itemprop="member"]//span[@itemprop="name"]/text()'
            description_xpath = '//div[@class="closer"]/text() | //div[@class="closer"]//text()'
            language_xpath = "//div[@class='col-xs-12 col-sm-12 col-md-6 prof-language' and @title='English']/text()"

            # Extract details using XPaths
            purpose = response.xpath(PURPOSE_XPATH).extract_first("")
            office_phone = response.xpath(office_phone_xpath).get(default="").strip()
            fax_number = response.xpath(fax_number_xpath).get(default="").strip()
            agent_phone = response.xpath(agent_phone_xpath).get(default="").strip()
            address_parts = response.xpath(address_xpath).getall()
            address = " ".join(part.strip() for part in address_parts if part.strip())
            description = response.xpath(description_xpath).getall()
            description = ' '.join(desc.strip() for desc in description if desc.strip())
            language = response.xpath(language_xpath).get(default="").strip()

            # Initialize address components
            street = city = state = country = zip_code = "Unknown"

            if address:
                address_components = address.split(", ")
                street = address_components[0].strip()
                if len(address_components) >= 3:
                    state = address_components[-2].strip()
                    city = address_components[-3].strip()  # Assuming city is the one before state
                country_zip = address_components[-1].strip()
                zip_code = country_zip.split(" ")[-1].strip() if country_zip else ""

            # Create a dictionary for the agent details
            agent_details = {
                "profile_url": url,
                "office_phone_numbers": [office_phone, fax_number],
                "agent_phone_numbers": [agent_phone],
                "address": street,
                "city": city,
                "state": state,
                "country": "United States",
                "zip_code": zip_code,
                "office_name": office_name_xpath,
                "description": description,
                "languages": [language],
                "title": purpose,
                "socials": {}
            }

            # Data insertion to MongoDB
            self.pipeline.process_agent_details(agent_details)

            return agent_details

        except Exception as e:
            logging.error(f"Failed to fetch details for {url}: {e}")
            return None

    def run(self):
        """Run the scraper for a list of profile URLs."""
        profile_urls = self.get_agent_profile_urls()
        for url in profile_urls:
            logging.info(f"Processing profile URL: {url}")
            self.fetch_agent_details(url)


if __name__ == "__main__":
    scraper = REMAXAgentScraper()
    scraper.run()
