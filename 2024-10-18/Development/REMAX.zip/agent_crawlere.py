# crawler.py

import requests
from bs4 import BeautifulSoup
import logging
from settings import LOGGING_LEVEL, LOGGING_FILENAME
from pipelines import MongoDBPipeline

# Set up logging
logging.basicConfig(level=LOGGING_LEVEL, filename=LOGGING_FILENAME,
                    format='%(asctime)s - %(levelname)s - %(message)s')


class REMAXScraper:
    def __init__(self):
        """Initialization: Set up MongoDB connection and other variables."""
        self.pipeline = MongoDBPipeline()
        self.base_url = "https://global.remax.com/handlers/officeagentsearch.ashx?mode=list&type=2&regionId=1000&regionRowId=&provinceId=&cityId=&localzoneId=&name=&location=&spokenLanguageCode=&page={}&countryCode=US&countryEnuName=USA&countryName=USA&selmode=residential&officeId=&TargetLng=&TargetLat="

    def get_agent_details(self, url):
        """Response Handling: Fetch and process agent profile data."""
        try:
            response = requests.get(url)
            response.raise_for_status()
            soup = BeautifulSoup(response.text, 'html.parser')
            return self.parse_agent_html(soup)
        except requests.RequestException as e:
            logging.error(f"Request error for URL {url}: {e}")
            return []
        except Exception as e:
            logging.error(f"Error processing URL {url}: {e}")
            return []

    def parse_agent_html(self, soup):
        """Defining XPath/HTML Parsing: Extract agent details."""
        agent_items = soup.find_all('div', class_='officeagent-list-item')
        agents = []

        for agent_item in agent_items:
            # Extract the profile URL
            profile_url = agent_item.find('a', class_='officeagent-pic')['href']
            agents.append({'profile_url': profile_url})  # Store only the profile URL

        return agents

    def scrape_agent_profiles(self):
        """Scraping Process: Iterate through agent pages and extract data."""
        all_agents = []
        page = 1

        while True:
            # Create URL for each page
            url = self.base_url.format(page)
            logging.info(f"Fetching data from: {url}")

            # Response Handling and Extraction
            agents = self.get_agent_details(url)

            # Break if no more agents are found
            if not agents:
                logging.info("No more agents found, ending the scrape.")
                break

            all_agents.extend(agents)
            page += 1

            # Stop if we reach around 2500 agents
            if len(all_agents) >= 2500:
                logging.info(f"Reached the target of {len(all_agents)} agents, ending the scrape.")
                break

        # Clean and insert the collected agent data
        for agent in all_agents:
            self.pipeline.process_profile_url(agent['profile_url'])

    def run(self):
        """Run the full scraping process."""
        self.scrape_agent_profiles()


if __name__ == "__main__":
    scraper = REMAXScraper()
    scraper.run()
