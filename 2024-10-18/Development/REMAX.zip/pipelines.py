# pipelines.py

from pymongo import MongoClient
from settings import MONGODB_URI, DATABASE_NAME, COLLECTION_PROFILE_URLS, COLLECTION_AGENT_DETAILS
import logging

class MongoDBPipeline:
    def __init__(self):
        # MongoDB connection setup
        self.client = MongoClient(MONGODB_URI)
        self.db = self.client[DATABASE_NAME]
        self.profile_collection = self.db[COLLECTION_PROFILE_URLS]
        self.agent_collection = self.db[COLLECTION_AGENT_DETAILS]

    def process_profile_url(self, profile_url):
        """Insert profile URL into MongoDB."""
        self.profile_collection.insert_one({'profile_url': profile_url})
        logging.info(f"Inserted profile URL: {profile_url}")

    def process_agent_details(self, agent_details):
        """Insert agent details into MongoDB."""
        self.agent_collection.insert_one(agent_details)
        logging.info(f"Inserted agent details for {agent_details['profile_url']}")
