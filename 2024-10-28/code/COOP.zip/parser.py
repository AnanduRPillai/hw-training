import logging
import re
from parsel import Selector
from datetime import datetime
from pymongo import MongoClient
from curl_cffi import requests
import time
import settings
from pipeline import MongoDBPipeline

class ProductScraper:
    def __init__(self):
        # Initialize MongoDB client and collections
        self.client = MongoClient(settings.MONGO_DB)
        self.db = self.client[settings.MONGO_DB]
        self.url_collection = self.db[settings.MONGO_COLLECTION_URL]
        self.output_collection = self.db[settings.MONGO_COLLECTION_DATA]
        self.session = requests.Session()
        self.pipeline = MongoDBPipeline.from_settings(settings)
        self.pipeline.open_spider(None)

    def scrape_product_data(self, url):
        try:
            logging.debug(f"Fetching URL: {url}")
            response = self.session.get(url, timeout=30, headers=settings.HEADERS, impersonate="chrome101")
            response.raise_for_status()  # Raise an error for bad status codes (4xx, 5xx)
            logging.debug(f"Response received for URL: {url}")

            # Use parsel to parse the HTML content
            selector = Selector(response.text)

        # Extract the unique ID from the URL
        unique_id = url.split("/")[-1]

        # Default fields
        competitor_name = "coop"
        store_name = ""  # Populate this as needed
        store_addressline1 = ""  # Populate this as needed
        store_addressline2 = ""  # Populate this as needed
        store_suburb = ""  # Populate this as needed
        store_state = ""  # Populate this as needed
        store_postcode = ""  # Populate this as needed
        store_addressid = ""  # Populate this as needed
        extraction_date = datetime.now().strftime("%Y-%m-%d")  # Dynamic extraction date

        # Example extraction; adjust based on actual HTML structure
        product_name = selector.xpath("//h1/text()").get(default="").strip()
        brand = selector.xpath('//div[@class="productBasicInfo__productMeta"]//span[@class="productBasicInfo__productMeta-value-item"]/span/text()').get(default="").strip()
        brand_type = ""  # Populate this as needed
        grammage_quantity = selector.xpath('//span[@itemprop="value" and @data-testauto="productweight"]/text()').get(default="").strip()
        grammage_unit = selector.xpath('//span[@class="productBasicInfo__quantity-text"]/text()[2]').get(default="").strip()
        drained_weight = selector.xpath('//div[@class="productInformation__row row"]//h3[contains(text(), "Gewicht")]/following-sibling::div[contains(@class, "productInformation__content")]/text()').re_first(r'Abtropfgewicht:\s*([\d\.]+ g)') or ""

        # Extract the full text containing both prices
        prices = selector.xpath('//dt[@class="productBasicInfo__price-label productBasicInfo__price-value-save visuallyhidden"]/text()').get()

        # Clean up the string and split into selling and regular prices
        if prices:
            prices_list = prices.strip().split()  # This will create a list of price components

            # Default values
            selling_price = None
            regular_price = None

            # Set prices based on availability
            if len(prices_list) >= 3:
                selling_price = prices_list[0]  # This will be "4.45"
                regular_price = prices_list[2]  # This will be "4.95"
            elif len(prices_list) == 2:
                # In case there is only one price
                selling_price = prices_list[0]
                regular_price = prices_list[0]
            else:
                selling_price = regular_price = None
        else:
            selling_price = None
            regular_price = None

        # Set default for grammage_unit if it's empty or null
        if not grammage_unit:
            grammage_unit = "stück"

        # Extract product hierarchy from the URL
        hierarchy_parts = url.split('/')
# Find the index of 'p' to determine where to slice
        p_index = hierarchy_parts.index('p') if 'p' in hierarchy_parts else len(hierarchy_parts)

# Only get parts that come before the 'p' segment
        product_hierarchy = ["Startseite"] + hierarchy_parts[4:p_index]  # Adding default level

# Ensure there are 7 levels, fill with empty strings if necessary
        product_hierarchy += [""] * (7 - len(product_hierarchy))  # Ensure there are 7 levels
        promotion_valid_from = ""
        promotion_valid_upto = ""
        promotion_type = ""
        percentage_discount = selector.xpath('//div[@class="productBasicInfo__price-text--overflow-hide"]//span[@class="productBasicInfo__price-text-saving-inner"]/text()').get(default="").strip()
        promotion_description = ""
        if percentage_discount:
            promotion_description = selector.xpath('//dt[@class="productBasicInfo__price-label productBasicInfo__price-value-save visuallyhidden"]/text()').get(default="").strip()
        else:
            promotion_description = ""
        breadcrumbs = " > ".join([
        product_hierarchy[0],
        product_hierarchy[1],
        product_hierarchy[2],
        product_hierarchy[3],
        product_hierarchy[4],
        product_hierarchy[5],
        product_hierarchy[6]
    ])
        promotion_description = selector.xpath('//dt[@class="productBasicInfo__price-label productBasicInfo__price-value-save visuallyhidden"]/text()').get(default="").strip()
        package_sizeof_sellingprice = ""
        per_unit_sizedescription = ""
        price_valid_from = ""
        price_per_unit = selector.xpath('//dd[@class="productBasicInfo__price-value productBasicInfo__price-value-per-weight"]//div[@class="inline" and @data-product-price-weight]/text()').get(default="").strip()
        multi_buy_item_count = ""
        multi_buy_items_price_total = ""
        currency = 'Swiss franc'
        pdp_url = url
        variants = ""
        description = ' '.join([text.strip() for text in selector.xpath('//div[@data-testauto="productdescription"]//text()[normalize-space()]').getall() if text.strip()])
        instructions = ""
        storage_instruction = ' '.join([text.strip() for text in selector.xpath('//div[@data-testauto="productstorage"]//text()[normalize-space()]').getall() if text.strip()])
        # Select only the "preparation" header and its related content
        preparation_instruction = ' '.join([text.strip() for text in selector.xpath('//h3[contains(text(), "Zubereitung")]/following-sibling::div//text()').getall() if text.strip()])
        preparation_instruction = preparation_instruction.encode('utf-8').decode('unicode_escape')
        preparation_instruction = re.sub(r'\s+', ' ', preparation_instruction).strip()
        preparation_instruction = re.sub(r'(?<=\w) (?=\w)', '', preparation_instruction)
        preparation_instruction = preparation_instruction.replace('\u00c2', '').replace('\u00bc', '°')
        preparation_instruction = preparation_instruction.replace('\u00a0', ' ').strip()
        preparation_text = ' '.join(p.strip() for p in preparation_instruction if p.strip())
        instructions_for_use = ' '.join([text.strip() for text in selector.xpath('//h3[contains(text(), "Verwendungshinweise")]/following-sibling::div//text()').getall() if text.strip()])
        instructions_for_use = instructions_for_use.strip() if instructions_for_use else ""
        country_of_production = ' '.join([text.strip() for text in selector.xpath('//div[@data-testauto="productcountry"]//text()[normalize-space()]').getall() if text.strip()])
        allergy_info = ' '.join([text.strip() for text in selector.xpath('//div[@data-testauto="productingredients"]//b//text()[normalize-space()]').getall() if text.strip()])
        age_of_the_product = ""
        age_recommendation = selector.xpath('//h3[text()[contains(., "Altersempfehlung")]]/following-sibling::div/text()').get() or ""
        flavour = ""
        nutritions = ""
        nutritional_items = tree.xpath('//li[@data-testauto="nutrition-row"]')
        nutritional_data = []
        for item in nutritional_items:
            label = item.xpath('.//span[@class="list--dotted-item__label-text"]/text()')
            amount = item.xpath('.//span[@class="list--dotted-item__amount"]/span/text()')
            if label and amount:
                nutritional_data.append(f"{label[0].strip()}: {amount[0].strip()}")
        nutritional_information = ', '.join(nutritional_data)
        vitamins = ""
        labelling = ""
        grade = ""
        region = ""
        packaging_xpath = '//div[@class="productInformation productInformation--hasBrandLink productInformation--characteristics"]//div[contains(@class, "productInformation__row") and .//div[contains(text(), "Verpackung")]]//div[contains(@class, "productInformation__content")]//text()'

        packaging_info = selector.xpath(packaging_xpath).get()
        if packaging_info:
            packaging_info_cleaned = ' '.join([text.strip() for text in packaging_info if text.strip()])
        else:
             packaging_info_cleaned = ""

        receipies = ""
        processed_food = ""
        barcode = ""
        frozen = ""
        chilled = ""
        if url is not None:
           if 'bio' in url:
              organictype = 'Organic'
           else:
              organictype = "Non-organic"
        cooking_part = ""
        handmade = ""
        max_heating_temperature = ""
        special_info = ' '.join([text.strip() for text in selector.xpath('//div[@class="productInformation productInformation--hasBrandLink"]/text()').getall() if text.strip()])
        label_information = ""
        height = tree.xpath('//div[contains(text(), "Höhe")]/following-sibling::div/text()')
        length = tree.xpath('//div[contains(text(), "Länge")]/following-sibling::div/text()')
        width = tree.xpath('//div[contains(text(), "Breite")]/following-sibling::div/text()')
        dimensions = ""
        if height and length and width:
            dimensions = f"{height[0].strip()} x {length[0].strip()} x {width[0].strip()}"

        special_nutrition_purpose = ""
        feeding_recommendation = ""
        warranty = ""
        color = ' '.join([text.strip() for text in selector.xpath('//div[contains(text(), "Farbe")]/following-sibling::div/text()').getall() if text.strip()])
        model_number = ' '.join([text.strip() for text in selector.xpath('//div[contains(text(), "Modellnummer")]/following-sibling::div/text()').getall() if text.strip()])
        material = ' '.join([text.strip() for text in selector.xpath('//div[contains(text(), "Hauptmaterial")]/following-sibling::div/text()').getall() if text.strip()])
        usp = ""
        dosage_recommendation = ""
        tasting_note = ' '.join([text.strip() for text in selector.xpath('//h3[text()[contains(., "Geschmack")]]/following-sibling::div/text()').getall() if text.strip()])
        food_preservation = ""
        size =  ' '.join([text.strip() for text in selector.xpath('//div[contains(text(), "Grösse")]/following-sibling::div/text()').getall() if text.strip()])
        rating_text = selector.xpath('//div[@class="rating"]//span[contains(@class, "visuallyhidden")]/text()').get()
        rating_value = re.search(r'[\d.]+', rating_text).group() if rating_text else ""
        review_count = tree.xpath('//span[@class="rating__amount"]//span[@itemprop="reviewCount"]/text()')
        review = review_count[0].strip() if review_count else ""
        competitor_product_key = ""
        fit_guide = ""
        occasion = ""
        material_composition = ""
        style = ""
        care_instructions = ""
        heel_type = ""
        heel_height = ""
        upc = ""
        features = ""
        dietary_lifestyle = ""
        manufacturer_address = ""
        importer_address = ""
        distributor_address = ' '.join([text.strip() for text in selector.xpath('//h3[text()[contains(., "Inverkehrbringer")]]/following-sibling::div/text()').getall() if text.strip()])
        vinification_details = ""
        recycling_information = ""
        return_address = ""
        alcohol_by_volume = ' '.join([text.strip() for text in selector.xpath('//div[contains(text(), "Alkoholgehalt")]/following-sibling::div/text()').getall() if text.strip()])
        beer_deg = ""
        netcontent = ""
        netweight = ""
        site_shown_uom = f"{grammage_quantity} {grammage_unit}"
        ingredients_list = selector.xpath('//div[@data-testauto="productingredients"]//text()[normalize-space()]').getall()
        if ingredients_list is None:
            ingredients_list = ""
        ingredients = ' '.join([text.strip() for text in ingredients_list if text.strip()])
        random_weight_flag = ""
        instock_text = selector.xpath('//div[contains(@class, "productAvailability productAvailability--product-detail")]//span[@class="productAvailability__notice"]/text()').get(default="").strip()
        instock_text = re.sub(r'[\r\n\s]+', ' ', instock_text).strip()

        # Set instock based on the exact text
        instock = False if instock_text == "Dieses Produkt ist zurzeit online nicht verfügbar" else True
        promo_limit = ""
        product_unique_key = url.split("/")[-1] + "P"
        multibuy_items_pricesingle = ""
        perfect_match =  ' '.join([text.strip() for text in selector.xpath('//div[contains(text(), "Passt zu")]/following-sibling::div/text()').getall() if text.strip()])
        servings_per_pack = ""
        warning = ""
        suitable_for = ""
        standard_drinks = ""
        environmental = ""
        grape_variety = address = ' '.join([text.strip() for text in selector.xpath('//div[contains(text(), "Rebsorte")]/following-sibling::div/text()').getall() if text.strip()])
        reatil_limit = ""
         # Extract high-resolution image URLs and file names
        image_url_1 = selector.xpath("//div[@class='carousel__img-wrapper']/img/@src").get(default="")
        file_name_1 = f"{image_url_1.split('/')[-1].split('.')[0]}.png" if image_url_1 else ""
        image_url_1 = f"https:{image_url_1.split('?')[0]}" if image_url_1 else ""

        image_url_2 = selector.xpath("(//div[@class='carousel__img-wrapper']/img/@data-img-src | //div[@class='carousel__img-wrapper']/img/@data-img-src-zoom)[3]").get(default="")
        file_name_2 = f"{image_url_2.split('/')[-1].split('.')[0]}.png" if image_url_2 else ""
        image_url_2 = f"https:{image_url_2.split('?')[0]}" if image_url_2 else ""

        image_url_3 = selector.xpath("(//div[@class='carousel__img-wrapper']/img/@data-img-src | //div[@class='carousel__img-wrapper']/img/@data-img-src-zoom)[4]").get(default="")
        file_name_3 = f"{image_url_3.split('/')[-1].split('.')[0]}.png" if image_url_3 else ""
        image_url_3 = f"https:{image_url_3.split('?')[0]}" if image_url_3 else ""

        image_url_4 = selector.xpath("(//div[@class='carousel__img-wrapper']/img/@data-img-src | //div[@class='carousel__img-wrapper']/img/@data-img-src-zoom)[5]").get(default="")
        file_name_4 = f"{image_url_4.split('/')[-1].split('.')[0]}.png" if image_url_4 else ""
        image_url_4 = f"https:{image_url_4.split('?')[0]}" if image_url_4 else ""

        image_url_5 = selector.xpath("(//div[@class='carousel__img-wrapper']/img/@data-img-src | //div[@class='carousel__img-wrapper']/img/@data-img-src-zoom)[6]").get(default="")
        file_name_5 = f"{image_url_5.split('/')[-1].split('.')[0]}.png" if image_url_5 else ""
        image_url_5 = f"https:{image_url_5.split('?')[0]}" if image_url_5 else ""

        image_url_6 = selector.xpath("(//div[@class='carousel__img-wrapper']/img/@data-img-src | //div[@class='carousel__img-wrapper']/img/@data-img-src-zoom)[7]").get(default="")
        file_name_6 = f"{image_url_6.split('/')[-1].split('.')[0]}.png" if image_url_6 else ""
        image_url_6 = f"https:{image_url_6.split('?')[0]}" if image_url_6 else ""

        product_data = {
            "unique_id": unique_id,
            "competitor_name": competitor_name,
            "store_name": store_name,
            "store_addressline1": store_addressline1,
            "store_addressline2": store_addressline2,
            "store_suburb": store_suburb,
            "store_state": store_state,
            "store_postcode": store_postcode,
            "store_addressid": store_addressid,
            "extraction_date": extraction_date,
            "product_name": product_name,
            "brand": brand,
            "brand_type": brand_type,
            "grammage_quantity": grammage_quantity,
            "grammage_unit": grammage_unit,
            "drained_weight": drained_weight,
            "producthierarchy_level1": product_hierarchy[0],
            "producthierarchy_level2": product_hierarchy[1],
            "producthierarchy_level3": product_hierarchy[2],
            "producthierarchy_level4": product_hierarchy[3],
            "producthierarchy_level5": product_hierarchy[4],
            "producthierarchy_level6": product_hierarchy[5],
            "producthierarchy_level7": product_hierarchy[6],
            "selling_price": selling_price,
            "regular_price": regular_price,
            "price_was": regular_price if regular_price and selling_price and regular_price != selling_price else "",
            "promotion_price": selling_price if selling_price and regular_price and regular_price != selling_price else "",
             "promotion_valid_from": promotion_valid_from,
            "promotion_valid_upto": promotion_valid_upto,
            "promotion_type": promotion_type,
            "percentage_discount": percentage_discount,
            "promotion_description": promotion_description,
            "package_sizeof_sellingprice": package_sizeof_sellingprice,
            "per_unit_sizedescription": per_unit_sizedescription,
            "price_valid_from": price_valid_from,
            "price_per_unit": price_per_unit,
            "multi_buy_item_count": multi_buy_item_count,
            "multi_buy_items_price_total": multi_buy_items_price_total,
            "currency": currency,
            "breadcrumbs": breadcrumbs,  # New field for breadcrumbs
            "pdp_url": pdp_url,          # New field for PDP URL
            "variants": variants,
            "description": description,
            "instructions": instructions,
            "storage_instruction": storage_instruction,
            "preparationinstruction": preparation_text,
            "instrunction_for_use": instructions_for_use,
            "country_orgin": country_of_production,
            "allergens": allergy_info,
            "age_of_the_product": age_of_the_product,
            "age_recommendation": age_recommendation,
            "flavour": flavour,
            "nutritions": nutritions,
            "nutritional_information": nutritional_information,
            "vitamins": vitamins,
            "labelling": labelling,
            "grade": grade,
            "region": region,
            "packaging": packaging_info_cleaned,
            "receipies": receipies,
            "processed_food": processed_food,
            "barcode": barcode,
            "frozen": frozen,
            "chilled": chilled,
            "organictype": organictype,
            "cooking_part": cooking_part,
            "handmade": handmade,
            "max_heating_temperature": max_heating_temperature,
            "special_info": special_info,
            "label_information": label_information,
            "dimensions": dimensions,
            "special_nutrition_purpose": special_nutrition_purpose,
            "feeding_recommendation": feeding_recommendation,
            "warranty": warranty,
            "color": color,
            "model_number": model_number,
            "material": material,
            "usp": usp,
            "dosage_recommendation": dosage_recommendation,
            "tasting_note": tasting_note,
            "food_preservation": food_preservation,
            "size": size,
            "rating": rating_value,
            "review": review,
            "file_name_1": file_name_1,
            "image_url_1": image_url_1.split('?')[0] if image_url_1 else "",
            "file_name_2": file_name_2,
            "image_url_2": image_url_2.split('?')[0] if image_url_2 else "",
            "file_name_3": file_name_3,
            "image_url_3": image_url_3.split('?')[0] if image_url_3 else "",
            "file_name_4": file_name_4,
            "image_url_4": image_url_4.split('?')[0] if image_url_4 else "",
            "file_name_5": file_name_5,
            "image_url_5": image_url_5.split('?')[0] if image_url_5 else "",
            "file_name_6": file_name_6,
            "image_url_6": image_url_6.split('?')[0] if image_url_6 else "",
            "competitor_product_key": competitor_product_key,
            "fit_guide": fit_guide,
            "occasion": occasion,
            "material_composition": material_composition,
            "style": style,
            "care_instructions": care_instructions,
            "heel_type": heel_type,
            "heel_height": heel_height,
            "upc": upc,
            "features": features,
            "dietary_lifestyle": dietary_lifestyle,
            "manufacturer_address": manufacturer_address,
            "importer_address": importer_address,
            "distributor_address": distributor_address,
            "vinification_details": vinification_details,
            "recycling_information": recycling_information,
            "return_address": return_address,
            "alcohol_by_volume": alcohol_by_volume,
            "beer_deg": beer_deg,
            "netcontent": netcontent,
            "netweight": netweight,
            "site_shown_uom": site_shown_uom,
            "ingrediants": ingredients,
            "random_weight_flag": random_weight_flag,
            "instock": instock,
            "promo_limit": promo_limit,
            "product_unique_key": product_unique_key,
            "multibuy_items_pricesingle": multibuy_items_pricesingle,
            "perfect_match": perfect_match,
            "servings_per_pack": servings_per_pack,
            "warning": warning,
            "suitable_for": suitable_for,
            "standard_drinks": standard_drinks,
            "environmental": environmental,
            "grape_variety": grape_variety,
            "retail_limit": reatil_limit
        }

        # If regular price and selling price are the same
        if regular_price and selling_price and regular_price == selling_price:
            product_data["price_was"] = ""
            product_data["promotion_price"] = ""

            logging.info(f"Successfully scraped data from URL: {url}")
            return product_data
        except Exception as e:
            logging.error(f"Error while scraping URL: {url} - Error: {str(e)}")
            return None

    def scrape_single_url(self):
        product_urls = self.url_collection.find({}, {"url": 1})

        for product in product_urls:
            url = product['url']
            logging.debug(f"Starting scrape for URL: {url}")
            time.sleep(2)
            product_data = self.scrape_product_data(url)

            if product_data:
                self.pipeline.process_item(product_data, None)
                # Save the scraped product data to the output collection
                try:
                    self.output_collection.insert_one(product_data)
                    logging.info(f"Scraped data successfully saved for URL: {url}.")
                except Exception as e:
                    logging.error(f"Error saving scraped data for URL: {url} - Error: {str(e)}")
            else:
                logging.warning(f"Failed to scrape data for URL: {url}")
    def close(self):
        self.pipeline.close_spider(None)
if __name__ == "__main__":
    # Set up logging to display debug information
    logging.basicConfig(
        level=logging.DEBUG,  # Use DEBUG to see detailed output
        format="%(asctime)s - %(levelname)s - %(message)s",
    )

    scraper = ProductScraper()
    scraper.scrape_single_url()