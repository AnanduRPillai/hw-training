from datetime import datetime

# Project-specific settings
CLIENT_NAME = "tcs_aldi"
COUNTRY_NAME = "switzerland"  # For "coop", COUNTRY_NAME is "switzerland"
PROJECT = "coop"  # This should be dynamically set to the site name you're working with (e.g., "coop", "mueller", "bipa")
FREQUENCY = "weekly"
ITERATION = datetime.now().strftime("%Y_%m_%d")

# Base URL and headers
BASE_URL = "https://www.coop.ch/de/"
HEADERS = {
   'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'cache-control': 'max-age=0',
    'sec-ch-device-memory': '4',
    'sec-ch-ua': '"Not/A)Brand";v="8", "Chromium";v="126", "Google Chrome";v="126"',
    'sec-ch-ua-arch': '"x86"',
    'sec-ch-ua-full-version-list': '"Not/A)Brand";v="8.0.0.0", "Chromium";v="126.0.6478.126", "Google Chrome";v="126.0.6478.126"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-model': '""',
    'sec-ch-ua-platform': '"Linux"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'none',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
}

# MongoDB configuration
MONGO_DB = f"{CLIENT_NAME}_{COUNTRY_NAME}_{FREQUENCY}_{ITERATION}"
MONGO_COLLECTION_URL = f"crawler{PROJECT}_url"  # For the crawler, collection name will be "{PROJECT}_url"
MONGO_COLLECTION_CATEGORY_URL = f"crawler{PROJECT}_category_url"  # New collection format
MONGO_COLLECTION_DATA = f"parser{PROJECT}_data"  # For the parser, collection name will be "{PROJECT}_data"
