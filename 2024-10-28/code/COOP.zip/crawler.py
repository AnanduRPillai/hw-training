import requests
import json
from parsel import Selector
from mongoengine import Document, StringField, DateTimeField, connect
from settings import HEADERS  # Assuming your headers are stored in settings.py
from datetime import datetime  # Import datetime

class URL(Document):
    url = StringField(required=True, unique=True)
    timestamp = DateTimeField(default=datetime.now)
class ProductURLFetcher:
    def __init__(self, db_name, collection_name, url_limit):
        connect(db_name)
        self.collection_name = collection_name
        self.total_product_urls = []
        self.url_limit = url_limit

    def fetch_base_urls(self):
        return [doc['url'] for doc in URL.objects()]

    def fetch_product_urls_from_base(self, base_url):
        page_number, page_size = 1, 30

        while len(self.total_product_urls) < self.url_limit:
            url = f'{base_url}?page={page_number}&pageSize={page_size}&q=%3Arelevance&sort=relevance'
            response = requests.get(url, headers=HEADERS)

            if response.status_code == 200:
                selector = Selector(response.text)
                json_ld_scripts = selector.xpath('//script/text()').getall()
                product_urls = []

                for script in json_ld_scripts:
                    try:
                        json_data = json.loads(script)
                        if isinstance(json_data, dict) and json_data.get('@type') == 'Product':
                            product_url = json_data.get('url')
                            if product_url:
                                product_urls.append(product_url)
                    except json.JSONDecodeError:
                        continue

                self.total_product_urls.extend(product_urls)

                # Exit if no more products returned
                if len(product_urls) < page_size:
                    print(f"No more products found on page {page_number}. Ending pagination.")
                    break

                page_number += 1  # Increment the page number to fetch the next page
            else:
                print(f"Failed to retrieve page {page_number}: {response.status_code}")
                break

    def run(self):
        base_urls = self.fetch_base_urls()
        if not base_urls:
            print("No base URLs to process. Exiting.")
            return

        print("Documents in the collection:")
        print("\n".join(base_urls) or "No URLs found in the collection.")

        for base_url in base_urls:
            self.fetch_product_urls_from_base(base_url)
            if len(self.total_product_urls) >= self.url_limit:
                break

        print(f'Total product URLs collected: {len(self.total_product_urls)}')
        print(self.total_product_urls)

        collection = self.db['crawlercoop_url']  # Change the collection name here
        if self.total_product_urls:
            # Prepare data with URL and timestamp
            timestamped_urls = [{"url": url, "timestamp": datetime.now()} for url in self.total_product_urls]
            collection.insert_many(timestamped_urls)

        print('Inserted URLs:')
        print("\n".join(self.total_product_urls))
        print(f'Inserted {len(self.total_product_urls)} URLs into MongoDB.')

# Create an instance of the ProductURLFetcher and run it
if __name__ == "__main__":
    fetcher = ProductURLFetcher('tcs_aldi_switzerland_weekly_2024_10_23', 'crawlercoop_category_url', 2500)
    fetcher.run()
