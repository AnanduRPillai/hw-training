import logging
from pymongo import MongoClient
from datetime import datetime

class MongoDBPipeline:
    def __init__(self, mongo_uri, mongo_db, collection_name):
        self.mongo_uri = mongo_uri
        self.mongo_db = mongo_db
        self.collection_name = collection_name
        self.client = None
        self.db = None

    @classmethod
    def from_settings(cls, settings):
        return cls(
            mongo_uri=settings.get('MONGO_URI'),
            mongo_db=settings.get('MONGO_DATABASE', 'scrapy_db'),
            collection_name=settings.get('MONGO_COLLECTION', 'product_data')
        )

    def open_spider(self, spider):
        """Initialize MongoDB client and database."""
        self.client = MongoClient(self.mongo_uri)
        self.db = self.client[self.mongo_db]
        logging.info(f"Connected to MongoDB at {self.mongo_uri}")

    def close_spider(self, spider):
        """Close MongoDB client."""
        if self.client:
            self.client.close()
            logging.info("Closed MongoDB connection")

    def process_item(self, item, spider):
        """Process and store item in MongoDB."""
        # Convert item to a dictionary and add extraction date if not present
        item_dict = dict(item)
        item_dict["extraction_date"] = item_dict.get("extraction_date", datetime.now().strftime('%Y-%m-%d'))

        # Upsert into the MongoDB collection
        self.db[self.collection_name].update_one(
            {'unique_id': item_dict.get("unique_id")},
            {'$set': item_dict},
            upsert=True
        )

        logging.info(f"Saved item with unique ID: {item_dict.get('unique_id')}")
        return item
