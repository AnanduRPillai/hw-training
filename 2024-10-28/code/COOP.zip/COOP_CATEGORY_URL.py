import requests
from lxml import html
from pymongo import MongoClient
from datetime import datetime

# Import project-specific settings
from settings import BASE_URL, HEADERS, MONGO_DB, MONGO_COLLECTION_CATEGORY_URL

# Connect to MongoDB
client = MongoClient('mongodb://localhost:27017/')
db = client[MONGO_DB]
url_collection = db[MONGO_COLLECTION_CATEGORY_URL]

# Send a GET request to the URL
response = requests.get(BASE_URL, headers=HEADERS)

# Check if the request was successful
if response.status_code == 200:
    # Parse the content using lxml
    tree = html.fromstring(response.content)

    # Define the XPath expression to extract URLs
    xpath_expression = '//li[contains(@class, "pageHeader__content-navigation-l1-item")]/a/@href'

    # Extract URLs
    urls = tree.xpath(xpath_expression)

    # Prepend the base URL to relative links and remove the extra "de" from the URL
    full_urls = [BASE_URL.replace('/de/de/', '/de/') + url.lstrip('/') for url in urls]

    # Print the extracted URLs (Optional)
    for url in full_urls:
        print(url)

    # Store URLs in MongoDB
    for url in full_urls:
        # Insert each URL into the MongoDB collection
        url_collection.insert_one({"url": url, "timestamp": datetime.now()})

    print(f"Successfully saved {len(full_urls)} URLs to MongoDB.")

else:
    print(f"Failed to retrieve content: {response.status_code}")
