# settings.py

# Base URL for the roster page
BASE_URL = "https://www.reecenichols.com/roster/agents/0"

# Headers for the request
HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Connection': 'keep-alive',
}

# MongoDB settings
MONGO_URI = 'mongodb://localhost:27017/'
MONGO_DATABASE = 'KW_monthly_2024_10_05'
MONGO_COLLECTION = 'reecenicholas_crawler'

# Output JSON file
OUTPUT_FILE = 'cleaned_reecenicholas.json'
