import requests
from parsel import Selector
import json
import re
import logging
import time
from pymongo import MongoClient
from settings import MONGO_URI, MONGO_DATABASE, MONGO_COLLECTION, OUTPUT_FILE  # Import MongoDB settings

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# MongoDB configuration
mongo_client = MongoClient(MONGO_URI)
db = mongo_client[MONGO_DATABASE]
collection = db[MONGO_COLLECTION]

# Create a session to persist parameters across requests
session = requests.Session()

def extract_agent_details(url):
    try:
        logging.info(f"Fetching agent page: {url}")
        response = session.get(url)
        response.raise_for_status()  # Raise an error for bad responses
    except requests.RequestException as e:
        logging.error(f"Failed to fetch agent page: {e}")
        return {}

    selector = Selector(response.text)

    # Extracting address using XPath
    address_parts = selector.xpath(
        '//li[@class="rng-agent-profile-contact-address"]/strong/text() | '
        '//li[@class="rng-agent-profile-contact-address"]/text()'
    ).getall()

    # Combine the address parts and strip extra whitespace
    full_address = " ".join(part.strip() for part in address_parts if part.strip())

    # Split the full address into components using regex
    match = re.search(r'(.+)\s+([\w\s]+),\s*(\w{2})\s+(\d+)', full_address)
    if match:
        street_address = match.group(1).strip()
        city = match.group(2).strip()
        state = match.group(3).strip()
        zipcode = match.group(4).strip()
    else:
        street_address = ""
        city = ""
        state = ""
        zipcode = ""

    # Extracting description using XPath
    description_parts = selector.xpath('//article[@class="rng-agent-profile-content"]//div//text()').getall()
    description = " ".join(part.strip() for part in description_parts if part.strip())
    description = description.replace('\u2013', '-').replace('\u00a0', ' ')  # Clean unwanted characters

    # Extracting social media URLs
    social_links = selector.xpath('//li[@class="rng-agent-profile-contact-social"]//li/a')
    socials = {
        "facebook": "",
        "twitter": "",
        "linkedin": "",
        "instagram": "",
        "other_urls": []
    }

    for link in social_links:
        url = link.xpath('@href').get()
        if url:  # Check if URL exists
            if "facebook.com" in url:
                socials["facebook"] = url
            elif "twitter.com" in url:
                socials["twitter"] = url
            elif "linkedin.com" in url:
                socials["linkedin"] = url
            elif "instagram.com" in url:
                socials["instagram"] = url
            else:
                socials["other_urls"].append(url)

    # Check if socials dictionary is empty and set to an empty dict if true
    if not any(socials.values()):
        socials = {}

    # Extracting languages using XPath
    languages_text = selector.xpath("//p[small[text()='Languages Spoken']]/text()[1]").get()
    languages = []
    if languages_text:
        languages = [lang.strip() for lang in languages_text if lang.strip()]  # Clean up whitespace

    # Construct the final agent details dictionary
    agent_details = {
        "description": description,
        "address": street_address,
        "city": city,
        "state": state,
        "zipcode": zipcode,
        "country": "United States",
        "socials": socials,
        "languages": languages  # Add languages as a list
    }

    return agent_details

def parse_agents_from_file(input_file):
    try:
        with open(input_file, 'r') as infile:
            for line in infile:
                agent_url = json.loads(line.strip()).get("profile_url")
                if agent_url:
                    agent_data = extract_agent_details(agent_url)

                    # Update the MongoDB document for the corresponding profile_url
                    if agent_data:
                        result = collection.update_one(
                            {"profile_url": agent_url},  # Match document by profile_url
                            {"$set": agent_data}  # Update the document with new data
                        )
                        if result.modified_count > 0:
                            logging.info(f"Updated data for agent: {agent_url}")
                        else:
                            logging.info(f"No changes made for agent: {agent_url}")

                    time.sleep(0.2)  # Reduced delay for faster parsing
                    logging.info(f"Processed agent: {agent_url}")

    except json.JSONDecodeError as e:
        logging.error(f"JSON decode error: {e}")
    except Exception as e:
        logging.error(f"An error occurred during processing: {e}")

# Define the input file with profile URLs
input_file = OUTPUT_FILE
parse_agents_from_file(input_file)

logging.info("Data extraction and database update complete.")
