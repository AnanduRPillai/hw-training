import requests
from parsel import Selector
import json
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Import settings
from settings import OUTPUT_FILE, BASE_URL, HEADERS

def extract_agents():
    logging.info(f"Fetching the roster page from {BASE_URL}.")
    try:
        response = requests.get(BASE_URL, headers=HEADERS)
        if response.status_code != 200:
            logging.error(f"Failed to fetch page: Status {response.status_code}")
            return

        selector = Selector(response.text)
        agents = []

        # Extract agent data
        for article in selector.xpath('//div[@id="rosterResults"]/article'):
            agent_url = article.xpath('.//a[@class="site-roster-card-image-link"]/@href').get()
            agent_url = f"https://www.reecenichols.com{agent_url}" if agent_url else ""
            if not agent_url:
                continue

            full_name = (article.xpath('.//h2/text()').get() or "").strip()
            name_parts = full_name.split()
            first_name, middle_name, last_name = name_parts[0], "", ""
            if len(name_parts) == 3:
                middle_name, last_name = name_parts[1], name_parts[2]
            elif len(name_parts) > 3:
                first_name, last_name = " ".join(name_parts[:-2]), " ".join(name_parts[-2:])

            image_url = article.xpath('.//a/div[@class="site-roster-card-image"]/@style').re_first(r'url\((.*?)\)', "") or ""
            role = (article.xpath('.//div[@class="site-roster-card-content-title"]/span/text()').get() or "").strip()
            phone_numbers = article.xpath('.//ul/li/a[contains(@href, "tel:")]/text()').getall()
            agent_data = {
                "profile_url": agent_url,
                "first_name": first_name,
                "middle_name": middle_name,
                "last_name": last_name,
                "image_url": image_url,
                "title": role,
                "agent_phone_numbers": [phone.strip() for phone in phone_numbers],
                "email": article.xpath('.//ul/li/a[contains(@href, "Contact")]/@href').get() or "",
                "website": article.xpath('.//ul/li/a[starts-with(@href, "https://")]/@href').get() or "",
                "office_name": (article.xpath('.//ul/li[not(a)]/text()').get() or "").strip(),
                "office_phone_numbers": []
            }
            agents.append(agent_data)
            logging.info(f"Extracted agent: {first_name} {last_name}")

        # Save to JSON file
        with open(OUTPUT_FILE, 'w', encoding='utf-8') as f:
            json.dump(agents, f, ensure_ascii=False, indent=4)
        logging.info(f"Saved {len(agents)} agents to {OUTPUT_FILE}.")

    except Exception as e:
        logging.error(f"An error occurred: {e}")

# Start extraction
extract_agents()
