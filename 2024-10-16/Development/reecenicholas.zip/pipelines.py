import json
import logging

# Import settings
from settings import OUTPUT_FILE

class SaveToJSONPipeline:
    def process_item(self, item):
        try:
            # Append each item to the JSON file
            with open(OUTPUT_FILE, 'a', encoding='utf-8') as f:
                json.dump(item, f, ensure_ascii=False)
                f.write('\n')
            logging.info(f"Saved item to {OUTPUT_FILE}")
        except Exception as e:
            logging.error(f"Error saving item to JSON: {e}")

        return item
