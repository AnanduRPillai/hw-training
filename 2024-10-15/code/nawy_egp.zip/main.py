import requests
from parsel import Selector
import re
import logging
from pymongo import MongoClient
from settings import MONGO_URI, DB_NAME, URL_COLLECTION, PARSED_COLLECTION

# Setup logging for debugging and tracking
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# MongoDB setup
client = MongoClient(MONGO_URI)
db = client[DB_NAME]
collection = db[URL_COLLECTION]
parsed_collection = db[PARSED_COLLECTION]

# Function to extract and structure data
def extract_data(url):
    try:
        response = requests.get(url, timeout=10)  # Set a timeout for faster failure in case of slow servers
        if response.status_code == 200:
            selector = Selector(response.text)

            # Extract fields using XPath
            price = selector.xpath('//div[@class="price-data"]/p[@class="headline-1 price"]/text()').get()
            price_value = price.strip() if price else ""

            max_price = selector.xpath('//div[@class="price-data max-price"]/p[@class="headline-1 price"]/text()').get()
            max_price_value = max_price.strip() if max_price else ""

            property_type = selector.xpath('//div[@class="header"]/div[1]/text()').get()
            property_type_value = property_type.strip() if property_type else ""

            type_field = selector.xpath("//span[@class='text-2' and @data-test='entity-type']/text()").get()
            type_value = type_field.strip() if type_field else "Property"

            title = selector.xpath('//div[@class="entity-name" and @itemprop="name"]/h1[@class="headline-2"]/text()').get()
            title_value = title.strip() if title else ""

            address_elements = selector.xpath("//h2[@class='entity-location']/span[@class='text-2']//text()").getall()
            full_address = " ".join(item.strip() for item in address_elements if item.strip()).replace("\n", "").strip()
            full_address = re.sub(r'\s+', ' ', full_address)  # Remove multiple spaces
            full_address = full_address if full_address else ""

            delivery_in = selector.xpath("//div[@class='rowData']/div[text()='Delivery In']/following-sibling::div[1]/text()").get()
            delivery_in_value = delivery_in.strip() if delivery_in else ""

            details = selector.xpath('//div[@class="header"]/div[2]//text()').getall()
            details_value = "".join([detail.strip() for detail in details if detail.strip()])
            details_value = details_value.replace("\u00b2", "2") if details_value else ""

            reference_number = selector.xpath('//div[@class="rowData"]/div[2]/text()').get()
            reference_number_value = reference_number.strip() if reference_number else ""

            bedrooms = selector.xpath('//div[@class="rowData"][div[1][text()="Bedrooms"]]/div[2]/text()').get()
            bedrooms_value = bedrooms.strip() if bedrooms else ""

            bathrooms = selector.xpath('//div[@class="rowData"][div[1][text()="Bathrooms"]]/div[2]/text()').get()
            bathrooms_value = bathrooms.strip() if bathrooms else ""

            compound = selector.xpath('//h2[@class="entity-location"]/span[@class="text-2"]/text()').get()
            compound_value = compound.strip().split(',')[0] if compound else ""

            sale_type = selector.xpath('//div[@class="rowData"][div[1][text()="Sale Type"]]/div[2]/text()').get()
            sale_type_value = sale_type.strip() if sale_type else ""

            finishing = selector.xpath('//div[@class="rowData"][div[1][text()="Finishing"]]/div[2]/text()').get()
            finishing_value = finishing.strip() if finishing else ""

            # Default values for additional fields
            ready_by = ""
            iteration_number = "2024_10_01"
            date = "2024-10-14"

            # Structure the data into a dictionary in the specified order
            data = {
                "url": url,
                "price": price_value,
                "max_price": max_price_value,
                "property_type": property_type_value,
                "type": type_value,
                "title": title_value,
                "address": full_address,
                "delivery_in": delivery_in_value,
                "details": details_value,
                "reference_number": reference_number_value,
                "bedrooms": bedrooms_value,
                "bathrooms": bathrooms_value,
                "compound": compound_value,
                "sale_type": sale_type_value,
                "finishing": finishing_value,
                "ready_by": ready_by,
                "iteration_number": iteration_number,
                "date": date
            }
            return data
        else:
            logging.warning(f"Failed to retrieve the page at {url}. Status code: {response.status_code}")
            return None
    except requests.exceptions.RequestException as e:
        logging.error(f"Error while requesting {url}: {e}")
        return None

# Read URLs from MongoDB and process each one
for document in collection.find():
    url = document.get("url")
    if url:
        logging.info(f"Processing URL: {url}")
        data = extract_data(url)
        if data:
            # Insert data directly into the 'parsed_data' collection
            parsed_collection.insert_one(data)
            logging.info(f"Data extracted and inserted into MongoDB for URL: {url}")
        else:
            logging.warning(f"Data extraction failed for URL: {url}")
