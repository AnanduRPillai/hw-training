from pymongo import MongoClient
from settings import MONGO_URI, DB_NAME, PARSED_COLLECTION

class MongoDBPipeline:
    def __init__(self):
        self.client = MongoClient(MONGO_URI)
        self.db = self.client[DB_NAME]
        self.collection = self.db[PARSED_COLLECTION]

    def process_item(self, item):
        # Store item in MongoDB
        self.collection.insert_one(item)
        return item
