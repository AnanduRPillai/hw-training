from multiprocessing import Process, Queue
from crawler import fetch_properties
from parser import extract_data
from pymongo import MongoClient
from settings import MONGO_URI, DB_NAME, URL_COLLECTION, PARSED_COLLECTION

def fetch_and_process(start_index, limit):
    # Fetch properties using the crawler
    properties = fetch_properties(start_index)

    # MongoDB setup
    mongo_client = MongoClient(MONGO_URI)
    db = mongo_client[DB_NAME]
    collection = db[URL_COLLECTION]
    parsed_collection = db[PARSED_COLLECTION]

    # Process each property URL
    for property in properties:
        property_slug = property.get("slug")
        compound_slug = property.get("compound", {}).get("slug")
        full_url = f"https://www.nawy.com/compound/{compound_slug}/property/{property_slug}"

        # Extract data from the property URL
        data = extract_data(full_url)
        if data:
            # Insert data into MongoDB
            parsed_collection.insert_one(data)

if __name__ == "__main__":
    start_indices = [0, 20, 40, 60]  # Define the start indices for different processes
    limit = 20  # Number of properties to fetch per request

    processes = []
    for start_index in start_indices:
        process = Process(target=fetch_and_process, args=(start_index, limit))
        processes.append(process)
        process.start()

    for process in processes:
        process.join()  # Wait for all processes to finish
