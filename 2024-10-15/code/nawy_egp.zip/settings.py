# Settings for the project

# MongoDB settings
MONGO_URI = "mongodb://localhost:27017/"
DB_NAME = "propertyfinder_monthly_2024_10_15"
URL_COLLECTION = "property_urls"
PARSED_COLLECTION = "parsed_data"

# Logging settings
LOGGING_LEVEL = "INFO"
LOGGING_FORMAT = "%(asctime)s - %(levelname)s - %(message)s"
