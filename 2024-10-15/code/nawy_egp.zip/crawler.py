import requests
import json
from pymongo import MongoClient  # Import MongoDB client
from settings import MONGO_URI, DB_NAME, URL_COLLECTION

# Define the base URL for the API
base_url = "https://webapi.cooingestate.com/api/properties/search"
token = "undefined"  # Ensure to replace this with a valid token if required
language = "en"
client_id = "1413608298.1728535"  # Client ID

# Initialize an empty list to store property data
all_properties = []

# MongoDB connection setup
mongo_client = MongoClient(MONGO_URI)  # Replace with your MongoDB URI
db = mongo_client[DB_NAME]  # Replace with your database name
collection = db[URL_COLLECTION]  # Replace with your collection name

# Function to fetch properties with pagination
def fetch_properties(start):
    # Prepare the payload for the POST request
    payload = {
        "token": token,
        "language": language,
        "client_id": client_id,
        "show": "property",  # Specifies that we want to show properties
        "start": start,      # Starting index for pagination
        "areas_ids": [2]     # The specified area ID
    }

    # Send the POST request
    response = requests.post(base_url, json=payload)

    # Check if the request was successful
    if response.status_code == 200:
        data = response.json()
        properties = data.get('values', [])
        return properties
    else:
        print(f"Failed to fetch data for start {start}: {response.status_code}")
        return []

# Loop through pages until no more properties are available
start_index = 0
limit = 20  # Number of properties to fetch per request (if applicable)
while True:
    print(f"Fetching properties starting from index {start_index}...")
    properties = fetch_properties(start_index)

    if not properties:
        print("No more properties found.")
        break

    # Extract only the required fields and construct the URL
    for property in properties:
        property_slug = property.get("slug")
        compound_slug = property.get("compound", {}).get("slug")

        # Construct the full URL
        full_url = f"https://www.nawy.com/compound/{compound_slug}/property/{property_slug}"

        # Store only the URL in the collection
        collection.insert_one({"url": full_url})  # Insert the URL into MongoDB
        all_properties.append(full_url)  # Optionally keep a list of URLs

    start_index += limit  # Update the start index for the next batch

# Output all URLs in JSON Lines format (optional)
with open('urls.jsonl', 'w') as f:
    for url in all_properties:
        json_line = json.dumps({"url": url})  # Convert URL to a JSON string
        f.write(json_line + '\n')  # Write the JSON string to the file with a newline
